#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "common.h"
#include<string.h>

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */

uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

    	return e_failure;
    }

    // No failure return e_success
    return e_success;
}
/* read and validate encode args function defintion */
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    /*check whether the file extn is  bmp or not 
     * if the file is bmp store it in the structure member
     * else return failure
    */ 
    if(strcmp(strstr(argv[2], ".bmp"), ".bmp") == 0)
    {
        encInfo->src_image_fname = argv[2];
    }
    else
    {
        return e_failure;
    }
    /*check the file extn is txt or not 
     * if its txt store it in secret_fname
     */
    if(strcmp(strstr(argv[3], ".txt"), ".txt") == 0)
    {
        encInfo->secret_fname=argv[3];
    }
    else
    {
        return e_failure;
    }
    /* if argv[4] is NULL, then give the default name and store
     *else store the same name */
    if(argv[4] == NULL)
    {
        encInfo->stego_image_fname="default.bmp";
    }
    else
    {
        encInfo->stego_image_fname=argv[4];
    }
    return e_success;
}

/* do_encoding function definition*/
Status do_encoding(EncodeInfo *encInfo)
{
    if(open_files(encInfo) == e_success)
    {
        printf("open file success\n");
        if(check_capacity(encInfo) == e_success)
        {
            printf("check capacity is success\n");
            if(copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
            {
                printf("copy bmp header is success\n");
                if(encode_magic_string(MAGIC_STRING, encInfo) == e_success)
                {
                    printf("magic string is copied successfully\n");
                    strcpy(encInfo->extn_secret_file, strstr(encInfo->secret_fname, "."));
                    if(encode_secret_file_extn_size(strlen(encInfo->extn_secret_file), encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
                    {
                        printf("secret file extension size is encoded\n");
                        if(encode_secret_file_extn(encInfo->extn_secret_file, encInfo) == e_success)
                        {
                            printf("secret file extension is encoded\n");
                            if(encode_secret_file_size(encInfo->size_secret_file, encInfo) ==e_success)
                            {
                                printf("secret file size is encoded\n");
                                if(encode_secret_file_data(encInfo) == e_success)
                                {
                                    printf("secret file data is encoded\n");
                                    if(copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
                                    {
                                        printf("Remaining image data is copied\n");
                                        return e_success;
                                    }
                                    else
                                    {
                                        printf("Remaining image data is not copied\n");
                                        return e_failure;
                                    }
                                }
                                else
                                {
                                    printf("secret file data is not encoded\n");
                                    return e_failure;
                                }
                            }
                            else
                            {
                                printf("secret file size is not encoded\n");
                                return e_failure;
                            }
                        }
                        else
                        {
                            printf("secret file extension is not encoded\n");
                            return e_failure;
                        }
                    }
                    else
                    {
                        printf("secret file extension size not is encoded\n");
                        return e_failure;
                    }
                }
                else
                {
                    printf("magic string is not copied successfully\n");
                    return e_failure;
                }
            }
            else
            {
                printf("copy bmp header is not success\n");
                return e_failure;
            }
        }
        else
        {
            printf("check capacity is not success\n");
            return e_failure;
        }
    }
    else
    {
        printf("open file success is failed\n");
        return e_failure;
    }
    return e_success;
}

/* check_capacity fuction definition
 * check the capacity of src file */ 
Status check_capacity(EncodeInfo *encInfo)
{
    encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);
   
    encInfo->size_secret_file = get_file_size(encInfo->fptr_secret);
    //printf("file size -> %ld\n",encInfo->size_secret_file);
    
    if(get_file_size(encInfo->fptr_src_image) >= (54 + strlen(MAGIC_STRING) + 4 + encInfo->size_secret_file)*8)
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

/*function definition to get file size*/
uint get_file_size(FILE *fptr)
{
    fseek(fptr,0,SEEK_END);
    uint size = ftell(fptr);
    fseek(fptr,0,SEEK_SET);
    return size;
}
/*function definition to copy header file
 * first 54 bytes are the header it has to copy from source image to destination image */
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char arr[54];
    rewind(fptr_src_image);
    rewind(fptr_dest_image);
    
    //printf("copy postion -> %ld\n",fptr_src_image);
    fread(arr, 54, 1, fptr_src_image);
    fwrite(arr, 54, 1, fptr_dest_image);
    

    //printf("copy postion -> %ld\n",fptr_src_image);
     
     
    return e_success;
    
}


/* funtion definition for encoding magic string to output image file*/
 
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    fseek(encInfo->fptr_src_image,54L,SEEK_SET);
    fseek(encInfo->fptr_stego_image,54L,SEEK_SET);
   
    encode_data_to_image((char*)magic_string, strlen(magic_string), encInfo->fptr_src_image, encInfo->fptr_stego_image);
    return e_success;
    
}

/* function definition for encoding data to output image file */
Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
  {
    char str[8];
    
    //printf("postion -> %ld\n",fptr_src_image);
    for(int i = 0; i < size; i++)
    {
        fread(str, 8, 1, fptr_src_image);
        encode_byte_to_lsb(data[i], str);
        fwrite(str, 8, 1, fptr_stego_image);
    }
    //printf("postion end -> %ld\n",fptr_src_image);
    return e_success;
}

/* function definition for encoding each byte of magic string to lsb */

Status encode_byte_to_lsb(char data, char *image_buffer)
{
    
  
    for(int i=0;i<8;i++)
    {
        image_buffer[i]=(image_buffer[i]&0xFE) | (data&(1<<i))>>i;
        
    }
}
/*function definition for encoding size to output image file */
Status encode_size_to_lsb(int size, char *image_buffer)
{
    
    unsigned int data = 8;
    for(int i = 0; i<32; i++)
    {
       image_buffer[i]=(image_buffer[i]&0xFE) | (size&(1<<i))>>i;
       /*if((size >> (31 - i)) & 1)
        {
            image_buffer[i] = image_buffer[i] | 1;
        }
        else
        {
            image_buffer[i] = image_buffer[i] & ~1;
        }*/
    }
	
}

/* function definition for encoding secret file extn for size output image file*/
Status encode_secret_file_extn_size(int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char str[32];
    fread(str,32, 1, fptr_src_image);
    encode_size_to_lsb(size, str);
    fwrite(str,32, 1, fptr_stego_image);
    return e_success;

}


/*function definition for secret file extn to output image file */
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    encode_data_to_image((char*)file_extn, strlen(file_extn), encInfo->fptr_src_image, encInfo->fptr_stego_image);
    return e_success;
}
/* function definition for encoding secret file size*/ 
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    char arr[32];
    fread(arr, 32, 1, encInfo->fptr_src_image);
    encode_size_to_lsb(file_size, arr);
    fwrite(arr, 32, 1, encInfo->fptr_stego_image);
    return e_success;
}
/* to store the secret file data in image
 * first move the file pointer to the begining in secret file using fseek
 * create an array of size of secret file to store the secret file data
 * call the encode_byte_to image function 
 */

//function defintion of encode secret file data to the output image//
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    fseek(encInfo->fptr_secret, 0 , SEEK_SET);
    char str[encInfo->size_secret_file];
    fread(str, encInfo->size_secret_file, 1, encInfo->fptr_secret);
    encode_data_to_image(str, strlen(str), encInfo->fptr_src_image, encInfo->fptr_stego_image);
    return e_success;
}
/* copying the remaining data through byte by byte using fread and fwrite
 * while loop contains the fread so the loop runs until the condition is false
 * fread will be 0 when it reaches the end of file
 */
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)           
{
    char ch;
    while((fread(&ch, 1, 1, fptr_src))>0)
    {
        fwrite(&ch,1,1,fptr_dest);
    }
    return e_success;
}


            





                
